library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity InstructionExecute is
	port(clk,rst:in std_logic;
        valid_ins_in,reg_write_in,reg_read_1_in,reg_read_2_in: in std_logic;
        reg_write_add_in,reg_read_add_1_in,reg_read _add_2_in: in std_logic_vector(2 downto 0); 
        read_c_in,read_z_in,z_write_in,c_write_in,pc_change_in,Mem_Write_in: in std_logic;
        reg_write_val_available_in,mem_write_val_available_in: in std_logic;
        mem_write_val_in,mem_write_val_in: in std_logic_vector(15 downto 0);
        opcode_in : in std_logic_vector(3 downto 0);
        cz_in:  in std_logic_vector(1 downto 0);


        valid_ins_out:,reg_write_out,reg_read_1_out,reg_read_2_out: out std_logic;
        reg_write_add_out,reg_read_add_1_out,reg_read _add_2_out: out std_logic_vector(2 downto 0); 
        read_c_out,read_z_out,z_write_out,c_write_out,pc_change_out,Mem_Write_out: out std_logic;
        reg_write_val_available_out,mem_write_val_available_out: out std_logic;
        mem_write_val_out,mem_write_val_out: out std_logic_vector(15 downto 0);
        opcode_out : out std_logic_vector(3 downto 0);
        cz_out:  out std_logic_vector(1 downto 0));

end entity;

architecture InstructionExecute_arc of InstructionExecute is
    signal stall:std_logic;

    signal valid_ins_in_s1:,reg_write_in_s1,reg_read_1_in_s1,reg_read_2_in_s1:std_logic;
    signal reg_write_add_in_s1,reg_read_add_1_in_s1,reg_read _add_2_in_s1:std_logic_vector(2 downto 0); 
    signal read_c_in_s1,read_z_in_s1,z_write_in_s1,c_write_in_s1,pc_change_in_s1,Mem_Write_in_s1:std_logic;
    signal reg_write_val_available_in_s1,mem_write_val_available_in_s1: in std_logic;
    signal mem_write_val_in_s1,mem_write_val_in_s1: in std_logic_vector(15 downto 0);
    signAL opcode_in_s1 :std_logic_vector(3 downto 0);
    signal cz_in_s1: std_logic_vector(1 downto 0);

    signal valid_ins_out_s2:,reg_write_out_s2,reg_read_1_out_s2,reg_read_2_out_s2:std_logic;
    signal reg_write_add_out_s2,reg_read_add_1_out_s2,reg_read _add_2_out_s2:std_logic_vector(2 downto 0); 
    signal read_c_out_s2,read_z_out_s2,z_write_out_s2,c_write_out_s2,pc_change_out_s2,Mem_Write_out_s2:std_logic;
    signal reg_write_val_available_out_s2,mem_write_val_available_out_s2: out std_logic;
    signal mem_write_val_out_s2,mem_write_val_out_s2: out std_logic_vector(15 downto 0);
    signal opcode_out_s2 : std_logic_vector(3 downto 0);
    signal cz_out_s2: std_logic_vector(1 downto 0);

    component ALU is
        port( ALU_control: in std_logic_vector(1 downto 0); 
                ALU_A: in std_logic_vector(15 downto 0); 
                ALU_B: in std_logic_vector(15 downto 0);
                ALU_C: out std_logic_vector(15 downto 0);
                z: out std_logic;
                c: out std_logic );
        
    end component;

    signal ALU_control:std_logic_vector(1 downto 0); 
    signal ALU_A,ALU_B:std_logic_vector(15 downto 0);
    signal ALU_C:std_logic_vector(15 downto 0);
    signal ALU_zero,ALU_carry: std_logic;
begin
    ALU1: ALU
    port map ( ALU_control=>ALU_control,ALU_A=>ALU_A,ALU_B=>ALU_B,ALU_C=>ALU_C,z=>ALU_zero,c=>ALU_carry);

	valid_ins_in_s1 <= valid_ins_in;
    valid_out_in_s1 <= valid_out_in;
    reg_write_in_s1 <= reg_write_in;
    reg_write_add_in_s1 <= reg_write_add_in;
    reg_read_1_in_s1 <= reg_read_1_in;
    reg_addr_1_in_s1 <= reg_addr_1_in;
    reg_read_2_in_s1 <= reg_read_2_in;
    reg_addr_2_in_s1 <= reg_addr_2_in;
    read_c_in_s1 <= read_c_in;
    read_z_in_s1 <= read_z_in;
    z_write_in_s1 <= z_write_in;
    c_write_in_s1 <= c_write_in;
    pc_change_in_s1 <= pc_change_in;
    Mem_Write_in_s1 <= Mem_Write_in;
    reg_write_val_available_in_s1 <= reg_write_val_available_in;
    mem_write_val_available_in_s1 <=  mem_write_val_available_in;
    reg_write_val_in_s1 <= reg_write_val_available_in;
    mem_write_val_in_s1 <=  mem_write_val_available_in;
    opcode_in_s1 <=  opcode_in;
    cz_in_s1 <= cz_in;

    valid_ins_out <= valid_ins_out_s2;
    valid_out_out <= valid_out_out_s2;
    reg_write_out <= reg_write_out_s2;
    reg_write_add_out <= reg_write_add_out_s2;
    reg_read_1_out <= reg_read_1_out_s2;
    reg_addr_1_out <= reg_addr_1_out_s2;
    reg_read_2_out <= reg_read_2_out_s2;
    reg_addr_2_out <= reg_addr_2_out_s2;
    read_c_out <= read_c_out_s2;
    read_z_out <= read_z_out_s2;
    z_write_out <= z_write_out_s2;
    c_write_out <= c_write_out_s2;
    pc_change_out <= pc_change_out_s2;
    Mem_Write_out <= Mem_Write_out_s2;
    reg_write_val_available_out <= reg_write_val_available_out_s2;
    mem_write_val_available_out <=  mem_write_val_available_out_s2;
    reg_write_val_out <= reg_write_val_available_out_s2;
    mem_write_val_out <=  mem_write_val_available_out_s2;
    opcode_out <=  opcode_out_s2;
    cz_out <= cz_out_s2;

	process (clk)
    begin
        if(rising_edge(clk)) then
            if(rst = '1') then
              
            else
                if(not stall) then
                    stall <= '0';
                    valid_ins_out_s2 <= valid_ins_in_s1;
                    valid_out_out_s2 <= valid_out_in_s1;
                    reg_write_out_s2 <= reg_write_in_s1;
                    reg_write_add_out_s2 <= reg_write_add_in_s1;
                    reg_read_1_out_s2 <= reg_read_1_in_s1;
                    reg_addr_1_out_s2 <= reg_addr_1_in_s1;
                    reg_read_2_out_s2 <= reg_read_2_in_s1;
                    reg_addr_2_out_s2 <= reg_addr_2_in_s1;
                    read_c_out_s2 <= read_c_in_s1;
                    read_z_out_s2 <= read_z_in_s1;
                    z_write_out_s2 <= z_write_in_s1;
                    c_write_out_s2 <= c_write_in_s1;
                    pc_change_out_s2 <= pc_change_in_s1;
                    Mem_Write_out_s2 <= Mem_Write_in_s1;
                    reg_write_val_available_out_s2 <= reg_write_val_available_in_s1;
                    mem_write_val_available_out_s2 <=  mem_write_val_available_in_s1;
                    reg_write_val_out_s2 <= reg_write_val_available_in_s1;
                    mem_write_val_out_s2 <=  mem_write_val_available_in_s1;
                    opcode_out_s2 <=  opcode_out_s1;
                    cz_out_s2 <= cz_out_s1;
                else 
                    stall  <= '0';
                end if;
            end if;
        end if;
    end process;

    process (stall,valid_in)
    begin
        valid_out <= valid_in and (not stall);
    end process;
    
    process(opcode_out_s2,cz)_outs2)
	begin
		case opcode is
			when "0001" => -- ADD,ADC,ADZ,ADL
				if(cz_out_s2 = "00") then --ADD
                    ALU_control <= "00";
                    ALU_A  <= reg_read_1_out_s2;
                    ALU_B  <= reg_read_2_out_s2;
                    reg_write_val_available_out_s2 <= 
                elsif (cz_out_s2 = "01") then --ADZ

                elsif (cz_out_s2 = "10") then --ADC

                else   --ADL
                end if;
				
		end case;
	end process;
end architecture;